# ژورنال باینری — نسخه آماده Build با گوشی

این نسخه برای ساخت APK بدون کامپیوتر آماده شده است.

## روش ساده با گوشی و GitHub

1. فایل ZIP را دانلود و Extract کنید.
2. وارد GitHub شوید و یک Repository خالی بسازید؛ مثلاً `BinaryJournal`.
3. تمام فایل‌های داخل این پوشه را در ریشه Repository آپلود کنید. پوشه `app` و فایل‌های `build.gradle` و `settings.gradle` باید مستقیماً در ریشه باشند.
4. Commit را انجام دهید.
5. GitHub به‌صورت خودکار Workflow با نام **Build APK** را اجرا می‌کند.
6. در Repository به بخش **Actions** بروید و اجرای **Build APK** را باز کنید.
7. بعد از پایان موفق، پایین صفحه بخش **Artifacts** ظاهر می‌شود.
8. فایل **BinaryJournal-debug-apk** را دانلود و Extract کنید.
9. فایل `app-debug.apk` را روی گوشی نصب کنید.

### اگر Workflow خودکار اجرا نشد
در GitHub به:
**Actions → Build APK → Run workflow**
بروید و اجرا را دستی شروع کنید.

### نکته امنیتی
این Build نسخه Debug است و برای نصب شخصی مناسب است. برای انتشار در Google Play بهتر است نسخه Release با امضای اختصاصی ساخته شود.

### مشخصات Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Java: 17
- Compile SDK: 35
- Minimum Android: 8.0 (API 26)
