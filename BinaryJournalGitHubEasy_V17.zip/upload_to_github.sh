#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg install git -y >/dev/null 2>&1 || true
if [ ! -d .git ]; then
  git init
fi
git add .
git commit -m "Initial Binary Journal Final" || true
git branch -M main
printf "GitHub repository HTTPS URL: "
read REPO
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO"
else
  git remote add origin "$REPO"
fi
git push -u origin main
