# آپلود آسان پروژه به GitHub فقط با گوشی

## روش پیشنهادی: Termux
این روش لازم نیست فایل‌های پروژه را تک‌تک در GitHub آپلود کنی.

### 1) Termux را نصب کن
از F-Droid نصبش کن.

### 2) فایل ZIP را در گوشی Extract کن
پوشه‌ای که این فایل داخلش است را پیدا کن.

### 3) Termux را باز کن و این دستورات را بزن

```bash
pkg update -y
pkg install git unzip -y
termux-setup-storage
```

وقتی اجازه دسترسی به فایل‌ها خواست، Allow را بزن.

### 4) وارد پوشه پروژه شو
اگر ZIP را در Downloads گذاشتی:

```bash
cd ~/storage/downloads/BinaryJournalMobileBuild
```

اگر نام پوشه فرق داشت، همان نام واقعی پوشه را استفاده کن.

### 5) Git را آماده کن

```bash
git init
git add .
git commit -m "Initial Binary Journal Final"
git branch -M main
```

### 6) آدرس Repository خودت را اضافه کن

در GitHub وارد Repository `BinaryJournal` شو و آدرس HTTPS آن را بردار. معمولاً شبیه این است:

```text
https://github.com/USERNAME/BinaryJournal.git
```

بعد در Termux:

```bash
git remote add origin https://github.com/USERNAME/BinaryJournal.git
git push -u origin main
```

وقتی GitHub رمز خواست، به‌جای Password باید **GitHub Personal Access Token (PAT)** را وارد کنی.

## بعد از آپلود
در GitHub برو به:

**Actions → Build APK → Run workflow**

بعد از پایان Build:

**Actions → آخرین اجرای موفق → Artifacts → BinaryJournal-debug-apk**

فایل APK را دانلود و روی گوشی نصب کن.

## نکته مهم
اگر GitHub از تو Token می‌خواهد و Token نداری، در GitHub از مسیر:

**Settings → Developer settings → Personal access tokens → Tokens (classic)**

یک Token بساز و برای Repository دسترسی لازم را بده.

Token را برای هیچ‌کس ارسال نکن و داخل فایل پروژه ذخیره نکن.
