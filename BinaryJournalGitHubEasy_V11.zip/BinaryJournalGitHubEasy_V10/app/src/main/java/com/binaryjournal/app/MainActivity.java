package com.binaryjournal.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.InputType;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    SharedPreferences db;
    ArrayList<Trade> trades = new ArrayList<>();
    ArrayList<String> symbols = new ArrayList<>();
    HashSet<String> fav = new HashSet<>();
    HashSet<String> favTf = new HashSet<>();
    HashSet<String> favExp = new HashSet<>();
    boolean darkMode = false;
    int edit = -1;
    Uri pendingImage;
    int NAVY, BG, CARD, MUTED, GREEN, RED, BLUE, BORDER;
    final String[] defaults={"EUR/USD","GBP/USD","USD/JPY","XAU/USD","EUR/GBP","GBP/JPY","AUD/USD","USD/CAD","USD/CHF","NZD/USD","BTC/USD","ETH/USD"};
    final String[] tfs={"5 ثانیه","10 ثانیه","15 ثانیه","30 ثانیه","1 دقیقه","3 دقیقه","5 دقیقه","15 دقیقه","30 دقیقه","1 ساعت","4 ساعت","روزانه"};
    final String[] exps={"5 ثانیه","10 ثانیه","15 ثانیه","30 ثانیه","1 دقیقه","2 دقیقه","3 دقیقه","5 دقیقه","10 دقیقه","15 دقیقه"};

    @Override public void onCreate(Bundle b){super.onCreate(b); db=getSharedPreferences("binary_journal",0); darkMode=db.getBoolean("dark",false); applyTheme(); load(); showDashboard();}
    void applyTheme(){if(darkMode){NAVY=Color.rgb(241,245,249);BG=Color.rgb(15,23,42);CARD=Color.rgb(30,41,59);MUTED=Color.rgb(148,163,184);GREEN=Color.rgb(74,222,128);RED=Color.rgb(248,113,113);BLUE=Color.rgb(96,165,250);BORDER=Color.rgb(51,65,85);getWindow().setStatusBarColor(Color.rgb(2,6,23));getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(0);}else{NAVY=Color.rgb(15,23,42);BG=Color.rgb(246,248,252);CARD=Color.WHITE;MUTED=Color.rgb(100,116,139);GREEN=Color.rgb(22,163,74);RED=Color.rgb(220,38,38);BLUE=Color.rgb(37,99,235);BORDER=Color.rgb(226,232,240);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);}}

    TextView text(String s,float size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(0,6,0,6);v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return v;}
    GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,14,18,14);c.setBackground(bg(CARD,22));return c;}
    Button action(String label,int color){Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setMinHeight(48);b.setPadding(16,0,16,0);b.setBackground(bg(color,18));return b;}
    void page(LinearLayout root,String title,String subtitle){
        root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(16,8,16,12);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(0,8,0,8);
        TextView h=text(title,25,NAVY);h.setTypeface(null,1);h.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);h.setSingleLine(false);h.setMaxLines(2);h.setIncludeFontPadding(true);
        head.addView(h,new LinearLayout.LayoutParams(0,154,1));
        root.addView(head,lp(0,6,0,0));
        if(subtitle!=null&&!subtitle.isEmpty()){
            TextView st=text(subtitle,14,MUTED);st.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);st.setPadding(0,4,0,12);st.setSingleLine(false);st.setMaxLines(2);st.setIncludeFontPadding(true);
            root.addView(st,new LinearLayout.LayoutParams(-1,70));
        }
    }
    ScrollView scroll(LinearLayout content){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(content);return s;}
    void setPage(View v){v.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());int left=view.getPaddingLeft(),right=view.getPaddingRight();int top=Math.max(view.getPaddingTop(),bars.top+8);int bottom=Math.max(view.getPaddingBottom(),bars.bottom+8);view.setPadding(left,top,right,bottom);return insets;});setContentView(v);v.requestApplyInsets();}

    void nav(LinearLayout root,int active){
        LinearLayout n=new LinearLayout(this);
        n.setPadding(8,12,8,14);
        n.setGravity(Gravity.CENTER);
        n.setBackground(bg(CARD,18));
        String[] icons={"⌂","▣","＋","▥","⚙"}; String[] labels={"خانه","معاملات","ثبت معامله","گزارش‌ها","تنظیمات"};
        for(int i=0;i<labels.length;i++){final int ix=i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(2,2,2,2);TextView ic=text(icons[i],30,i==active?BLUE:MUTED);ic.setGravity(Gravity.CENTER);TextView lab=text(labels[i],13,i==active?BLUE:NAVY);lab.setGravity(Gravity.CENTER);lab.setTypeface(null,i==active?1:0);ic.setPadding(0,0,0,0);lab.setPadding(0,0,0,0);item.addView(ic,new LinearLayout.LayoutParams(-1,56));item.addView(lab,new LinearLayout.LayoutParams(-1,46));item.setOnClickListener(x->{if(ix==0)showDashboard();else if(ix==1)showTrades();else if(ix==2){edit=-1;pendingImage=null;showForm();}else if(ix==3)showReports();else showSettings();});n.addView(item,new LinearLayout.LayoutParams(0,108,1));}
        root.addView(n,0,new LinearLayout.LayoutParams(-1,132));
    }
    TextView stat(String title,String value,int color){LinearLayout c=card();TextView a=text(title,12,MUTED);TextView b=text(value,22,color);b.setTypeface(null,1);c.addView(a);c.addView(b);TextView out=new TextView(this);out.setTag(c);return out;}

    void showDashboard(){
        LinearLayout r=new LinearLayout(this);page(r,"داشبورد","نمای کلی معاملات امروز");
        int w=0,l=0;double inv=0,p=0;HashMap<String,int[]> sm=new HashMap<>();
        for(Trade t:trades)if(sameDay(t.time)){if(t.win)w++;else l++;inv+=t.amount;p+=pnl(t);int[] a=sm.computeIfAbsent(t.symbol,k->new int[2]);a[0]++;if(t.win)a[1]++;}
        int total=w+l;double wr=total==0?0:100.0*w/total;
        LinearLayout hero=card();hero.setBackground(bg(darkMode?Color.rgb(30,41,59):NAVY,24));
        hero.addView(text("عملکرد امروز",14,Color.rgb(203,213,225)));TextView hv=text(String.format(Locale.US,"%.1f%%",wr),42,Color.WHITE);hv.setGravity(Gravity.RIGHT);hv.setTypeface(null,1);hero.addView(hv);
        hero.addView(text(total+" معامله   •   "+w+" برد   •   "+l+" باخت",14,Color.rgb(203,213,225)));hero.addView(text(String.format(Locale.US,"سود/زیان: %.2f    |    سرمایه‌گذاری: %.2f",p,inv),14,Color.WHITE));r.addView(hero,lp(0,0,0,14));
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.HORIZONTAL);stats.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        stats.addView(metric("برد",String.valueOf(w),GREEN),new LinearLayout.LayoutParams(0,92,1));stats.addView(gap(8),new LinearLayout.LayoutParams(8,1));stats.addView(metric("باخت",String.valueOf(l),RED),new LinearLayout.LayoutParams(0,92,1));stats.addView(gap(8),new LinearLayout.LayoutParams(8,1));stats.addView(metric("P/L",String.format(Locale.US,"%.2f",p),p>=0?GREEN:RED),new LinearLayout.LayoutParams(0,92,1));r.addView(stats,lp(0,0,0,14));
        TextView sec=text("عملکرد نمادهای امروز",18,NAVY);sec.setTypeface(null,1);r.addView(sec);
        ArrayList<String> ks=orderedSymbols(sm);
        if(ks.isEmpty()) r.addView(empty("هنوز معامله‌ای برای امروز ثبت نشده است."));
        else{
            GridLayout symbolGrid=new GridLayout(this);symbolGrid.setColumnCount(2);symbolGrid.setUseDefaultMargins(false);symbolGrid.setPadding(0,2,0,2);
            for(String ss:ks){int[] a=sm.get(ss);LinearLayout cell=symbolRow(ss,a[0],rate(a));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=104;gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(4,4,4,4);symbolGrid.addView(cell,gp);}
            ScrollView symbolScroll=new ScrollView(this);symbolScroll.setFillViewport(false);symbolScroll.setNestedScrollingEnabled(true);symbolScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);symbolScroll.addView(symbolGrid);
            r.addView(symbolScroll,new LinearLayout.LayoutParams(-1,360));
        }
        TextView rec=text("آخرین معاملات",18,NAVY);rec.setTypeface(null,1);r.addView(rec,lp(0,16,0,4));
        int shown=0;for(int i=trades.size()-1;i>=0&&shown<5;i--){Trade t=trades.get(i);r.addView(tradeRow(t,i));shown++;}
        Button add=action("＋  ثبت معامله جدید",BLUE);add.setOnClickListener(v->{edit=-1;pendingImage=null;showForm();});r.addView(add,lp(0,14,0,8));TextView credit=text("Design by Ali Bazargani",11,MUTED);credit.setGravity(Gravity.CENTER);r.addView(credit,lp(0,6,0,4));nav(r,0);setPage(r);
    }
    View gap(int x){Space s=new Space(this);return s;}
    LinearLayout metric(String title,String value,int color){LinearLayout c=card();c.setGravity(Gravity.CENTER);c.addView(text(title,12,MUTED));TextView v=text(value,22,color);v.setGravity(Gravity.CENTER);v.setTypeface(null,1);c.addView(v);return c;}
    TextView empty(String s){TextView e=text(s,14,MUTED);e.setGravity(Gravity.CENTER);e.setPadding(10,24,10,24);return e;}
    LinearLayout symbolRow(String s,int n,double wr){
        LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(10,8,10,8);
        TextView name=text((fav.contains(cleanSymbol(s))?"★ ":"")+cleanSymbol(s),14,NAVY);name.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);name.setSingleLine(true);
        TextView count=text(n+" معامله",12,MUTED);count.setGravity(Gravity.CENTER);count.setSingleLine(true);
        TextView left=text(String.format(Locale.US,"%.1f%%",wr),15,wr>=50?GREEN:RED);left.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);left.setSingleLine(true);
        c.addView(name,new LinearLayout.LayoutParams(0,88,1));
        c.addView(count,new LinearLayout.LayoutParams(78,88));
        c.addView(left,new LinearLayout.LayoutParams(72,88));
        return c;
    }
    LinearLayout tradeRow(Trade t,int ix){
        LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,26,18,26);c.setMinimumHeight(1500);c.setTag(t.id);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView res=text(t.win?"WIN   🟢":"LOSE  🔴",18,t.win?GREEN:RED);res.setTypeface(null,1);res.setGravity(Gravity.CENTER);top.addView(res,new LinearLayout.LayoutParams(120,82));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        mid.addView(text((fav.contains(cleanSymbol(t.symbol))?"★ ":"☆ ")+cleanSymbol(t.symbol)+"  •  "+t.dir,20,NAVY));
        mid.addView(text(t.tf+"  •  "+t.expiry+"  •  "+fmtTime(t.time),15,MUTED));
        mid.addView(text("مبلغ: "+fmt(t.amount)+"   |   Payout: "+fmt(t.payout)+"٪",15,MUTED));
        mid.addView(text(t.win?"سود: "+fmt(t.amount*t.payout/100.0):"ضرر: "+fmt(t.amount),15,t.win?GREEN:RED));
        mid.addView(text("شمسی: "+t.shamsiDate+"   |   میلادی: "+t.miladiDate,13,MUTED));
        top.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        if(t.image!=null&&!t.image.isEmpty()){
            ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setImageURI(Uri.parse(t.image));
            top.addView(thumb,new LinearLayout.LayoutParams(150,150));thumb.setOnClickListener(v->showImage(t.image));
        }
        c.addView(top);
        TextView tap=text("برای مشاهده جزئیات و Screenshot روی معامله بزنید",13,MUTED);tap.setGravity(Gravity.RIGHT);c.addView(tap,lp(0,18,0,24));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button eb=action("✎  ویرایش",BLUE);Button dbb=action("✕  حذف",RED);eb.setTextSize(17);dbb.setTextSize(17);
        actions.addView(eb,new LinearLayout.LayoutParams(0,82,1));actions.addView(gap(10),new LinearLayout.LayoutParams(10,1));actions.addView(dbb,new LinearLayout.LayoutParams(0,82,1));c.addView(actions);
        c.setOnClickListener(v->detailById(t.id));
        eb.setOnClickListener(v->{edit=indexById(t.id);pendingImage=null;showForm();});dbb.setOnClickListener(v->confirmDelete(indexById(t.id),null));
        return c;
    }

    void showTrades(){
        LinearLayout r=new LinearLayout(this);page(r,"معاملات","همه معاملات ذخیره‌شده");
        Button add=action("＋  ثبت معامله",BLUE);add.setOnClickListener(v->{edit=-1;pendingImage=null;showForm();});r.addView(add,lp(0,0,0,12));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setNestedScrollingEnabled(true);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        if(trades.isEmpty())list.addView(empty("هنوز معامله‌ای ثبت نشده است."));
        for(int i=trades.size()-1;i>=0;i--)list.addView(tradeRow(trades.get(i),i),lp(0,0,0,10));
        sv.addView(list);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));nav(r,1);setPage(r);
    }

    int indexById(String id){for(int i=0;i<trades.size();i++)if(trades.get(i).id.equals(id))return i;return -1;}
    void detailById(String id){int ix=indexById(id);if(ix>=0)detail(ix);}
    void detail(int ix){
        if(ix<0||ix>=trades.size())return;Trade t=trades.get(ix);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(22,8,22,4);box.setBackgroundColor(BG);
        box.addView(detailLine("نماد",(fav.contains(t.symbol)?"★ ":"")+t.symbol));box.addView(detailLine("جهت",t.dir));box.addView(detailLine("تایم‌فریم",t.tf));box.addView(detailLine("انقضا",t.expiry));box.addView(detailLine("مبلغ",fmt(t.amount)));box.addView(detailLine("Payout",fmt(t.payout)+"٪"));box.addView(detailLine("نتیجه",t.win?"WIN 🟢":"LOSE 🔴"));box.addView(detailLine("تاریخ شمسی",t.shamsiDate));box.addView(detailLine("تاریخ میلادی",t.miladiDate));box.addView(detailLine("ساعت معامله",fmtTime(t.time)));
        if(t.image!=null&&!t.image.isEmpty()){ImageView thumb=new ImageView(this);thumb.setImageURI(Uri.parse(t.image));thumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);box.addView(thumb,new LinearLayout.LayoutParams(-1,420));thumb.setOnClickListener(v->showImage(t.image));TextView hint=text("برای مشاهده و بزرگنمایی روی تصویر بزنید",12,MUTED);hint.setGravity(Gravity.CENTER);box.addView(hint);}
        ScrollView detailScroll=new ScrollView(this);detailScroll.setFillViewport(true);detailScroll.addView(box);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("جزئیات معامله").setView(detailScroll).setPositiveButton("ویرایش",null).setNegativeButton("حذف",null).setNeutralButton("بستن",null).create();
        dlg.setOnShowListener(z->{Button pb=dlg.getButton(AlertDialog.BUTTON_POSITIVE),nb=dlg.getButton(AlertDialog.BUTTON_NEGATIVE),cb=dlg.getButton(AlertDialog.BUTTON_NEUTRAL);pb.setMinHeight(56);nb.setMinHeight(56);cb.setMinHeight(56);pb.setTextSize(16);nb.setTextSize(16);cb.setTextSize(16);pb.setOnClickListener(v->{dlg.dismiss();edit=ix;pendingImage=null;showForm();});nb.setOnClickListener(v->confirmDelete(ix,dlg));});dlg.show();
    }
    TextView detailLine(String a,String b){TextView v=text(a+"    "+b,15,NAVY);v.setPadding(4,10,4,10);return v;}
    void confirmDelete(int ix,AlertDialog parent){new AlertDialog.Builder(this).setTitle("حذف معامله؟").setMessage("این معامله برای همیشه حذف شود؟").setPositiveButton("حذف",(d,w)->{trades.remove(ix);save();if(parent!=null)parent.dismiss();showTrades();}).setNegativeButton("انصراف",null).show();}

    void showImage(String uri){try{final ImageView iv=new ImageView(this);iv.setImageURI(Uri.parse(uri));iv.setScaleType(ImageView.ScaleType.FIT_CENTER);iv.setBackgroundColor(Color.BLACK);iv.setOnTouchListener(new ZoomTouch(iv));new AlertDialog.Builder(this).setTitle("Screenshot — زوم و جابه‌جایی").setView(iv).setPositiveButton("بستن",null).show();}catch(Exception e){Toast.makeText(this,"باز کردن تصویر ممکن نیست",Toast.LENGTH_SHORT).show();}}
    static class ZoomTouch implements View.OnTouchListener{ImageView v;Matrix m=new Matrix();float downX,downY,oldDist;ZoomTouch(ImageView x){v=x;}float dist(MotionEvent e){float x=e.getX(0)-e.getX(1),y=e.getY(0)-e.getY(1);return (float)Math.sqrt(x*x+y*y);}public boolean onTouch(View q,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downX=e.getX();downY=e.getY();return true;case MotionEvent.ACTION_POINTER_DOWN:oldDist=dist(e);return true;case MotionEvent.ACTION_MOVE:if(e.getPointerCount()==2&&oldDist>10){float nd=dist(e);float sc=nd/oldDist;m.postScale(sc,sc,e.getX(0),e.getY(0));oldDist=nd;}else{m.postTranslate(e.getX()-downX,e.getY()-downY);downX=e.getX();downY=e.getY();}v.setImageMatrix(m);return true;}return true;}}

    void showForm(){
        LinearLayout r=new LinearLayout(this);page(r,edit<0?"ثبت معامله":"ویرایش معامله","ثبت سریع معامله");Trade old=edit<0?new Trade():trades.get(edit);

        r.addView(text("نماد معاملاتی",13,MUTED));
        Spinner symbolSpinner=symbolSpinner(orderedSymbolList(),old.symbol);
        r.addView(symbolSpinner,lp(0,0,0,10));
        Button addSym=action("＋  افزودن نماد جدید",Color.rgb(71,85,105));r.addView(addSym,lp(0,0,0,12));addSym.setOnClickListener(v->addSymbolAndRefresh());

        r.addView(text("جهت معامله",13,MUTED));
        LinearLayout dirBox=choiceList(new String[]{"CALL 🟩","PUT 🟥"},old.dir.equals("CALL")?"CALL 🟩":"PUT 🟥");
        r.addView(dirBox,lp(0,0,0,10));

        r.addView(text("تایم‌فریم",13,MUTED));
        LinearLayout tfBox=dropdownChoice("تایم‌فریم",orderedValues(tfs,favTf),old.tf,favTf);
        r.addView(tfBox,lp(0,0,0,10));

        r.addView(text("زمان انقضا",13,MUTED));
        LinearLayout exBox=dropdownChoice("زمان انقضا",orderedValues(exps,favExp),old.expiry,favExp);
        r.addView(exBox,lp(0,0,0,10));

        EditText amount=numEdit("مبلغ معامله",edit<0?"":(old.amount==0?"":fmt(old.amount)));
        EditText payout=numEdit("Payout (درصد)",edit<0?"":(old.payout==0?"":fmt(old.payout)));
        r.addView(text("مبلغ معامله",13,MUTED));r.addView(fieldWrap(amount),lp(0,0,0,10));
        r.addView(text("Payout",13,MUTED));r.addView(fieldWrap(payout),lp(0,0,0,10));

        r.addView(text("نتیجه معامله",13,MUTED));
        LinearLayout resBox=choiceList(new String[]{"WIN   🟢","LOSE  🔴"},old.win?"WIN   🟢":"LOSE  🔴");
        r.addView(resBox,lp(0,0,0,10));

        TextView auto=text("🕒  زمان معامله هنگام ذخیره، خودکار از ساعت گوشی ثبت می‌شود",12,MUTED);auto.setPadding(4,10,4,14);r.addView(auto);
        LinearLayout imgCard=card();TextView it=text(old.image==null?"📷  Screenshot اضافه نشده":"📷  Screenshot انتخاب شده",14,NAVY);imgCard.addView(it);Button ib=action(old.image==null?"انتخاب تصویر":"تغییر تصویر",Color.rgb(71,85,105));imgCard.addView(ib);r.addView(imgCard,lp(0,0,0,10));ib.setOnClickListener(v->{Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("image/*");in.addCategory(Intent.CATEGORY_OPENABLE);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(in,55);});

        LinearLayout buttons=new LinearLayout(this);Button saveb=action(edit<0?"✓  ذخیره معامله":"✓  ذخیره تغییرات",BLUE);Button cancel=action("انصراف",Color.rgb(71,85,105));saveb.setTextSize(16);cancel.setTextSize(16);buttons.addView(saveb,new LinearLayout.LayoutParams(0,82,1));buttons.addView(gap(10),new LinearLayout.LayoutParams(10,1));buttons.addView(cancel,new LinearLayout.LayoutParams(0,82,1));r.addView(buttons,lp(0,0,0,12));
        saveb.setOnClickListener(v->{try{
            String symbol=String.valueOf(symbolSpinner.getSelectedItem()); if(symbol==null||symbol.equals("null")||symbol.isEmpty())throw new Exception();
            String dir=String.valueOf(dirBox.getTag());String tf=((Spinner)tfBox.getTag()).getSelectedItem().toString().replaceFirst("^[★☆]\\s*","").trim();String ex=((Spinner)exBox.getTag()).getSelectedItem().toString().replaceFirst("^[★☆]\\s*","").trim();String result=String.valueOf(resBox.getTag());
            double am=Double.parseDouble(normalizeNumber(amount.getText().toString()));double po=Double.parseDouble(normalizeNumber(payout.getText().toString()));
            if(am<=0||po<0||po>100)throw new Exception();
            Trade t=new Trade();t.symbol=symbol;t.dir=dir.startsWith("CALL")?"CALL":"PUT";t.tf=tf;t.expiry=ex;t.amount=am;t.payout=po;t.win=result.startsWith("WIN");t.id=edit<0?UUID.randomUUID().toString():old.id;t.time=edit<0?System.currentTimeMillis():old.time;t.miladiDate=edit<0?fmtGregorianDateTime(t.time):old.miladiDate;t.shamsiDate=edit<0?fmtJalaliDateTime(t.time):old.shamsiDate;t.image=pendingImage!=null?pendingImage.toString():old.image;
            if(edit<0)trades.add(t);else trades.set(edit,t);pendingImage=null;save();showTrades();
        }catch(Exception e){Toast.makeText(this,"مبلغ و Payout را درست وارد کنید",Toast.LENGTH_SHORT).show();}});
        cancel.setOnClickListener(v->showTrades());
        ScrollView sv=scroll(r);setPage(sv);
    }
    ArrayList<String> orderedValues(String[] vals,HashSet<String> favs){ArrayList<String>x=new ArrayList<>();for(String v:vals)if(favs.contains(v))x.add(v);for(String v:vals)if(!favs.contains(v))x.add(v);return x;}
    Spinner symbolSpinner(ArrayList<String> values,String selected){Spinner s=new Spinner(this);ArrayList<String> display=new ArrayList<>();for(String v:values){v=cleanSymbol(v);display.add((fav.contains(v)?"★  ":"☆  ")+v);}ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,display){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convertView,parent);v.setTextSize(17);v.setTextColor(NAVY);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(18,0,18,0);v.setMinHeight(58);return v;}@Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextSize(16);v.setTextColor(NAVY);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(18,0,18,0);v.setMinHeight(56);v.setBackgroundColor(CARD);return v;}};s.setAdapter(a);int idx=values.indexOf(selected);if(idx<0)idx=0;s.setSelection(idx);s.setMinimumHeight(58);s.setPadding(8,0,8,0);s.setBackground(bg(CARD,16));s.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return s;}
    LinearLayout dropdownChoice(String label,ArrayList<String> values,String selected,HashSet<String> favs){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.HORIZONTAL);box.setGravity(Gravity.CENTER_VERTICAL);box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Spinner sp=new Spinner(this);ArrayList<String> display=new ArrayList<>();for(String v:values)display.add((favs.contains(v)?"★  ":"")+v);
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,display){
            @Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convertView,parent);v.setTextSize(16);v.setTextColor(NAVY);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(16,0,16,0);v.setMinHeight(68);return v;}
            @Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextSize(16);v.setTextColor(NAVY);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(18,0,18,0);v.setMinHeight(62);v.setBackgroundColor(CARD);return v;}
        };
        sp.setAdapter(ad);int pos=values.indexOf(selected);if(pos<0)pos=0;sp.setSelection(pos);sp.setMinimumHeight(78);sp.setBackground(bg(CARD,16));sp.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button star=action(favs.contains(selected)?"★":"☆",favs.contains(selected)?BLUE:Color.rgb(71,85,105));star.setTextSize(22);star.setMinHeight(78);
        star.setOnClickListener(v->{String chosen=values.get(sp.getSelectedItemPosition());if(favs.contains(chosen))favs.remove(chosen);else favs.add(chosen);save();showForm();});
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){String chosen=values.get(position);star.setText(favs.contains(chosen)?"★":"☆");star.setBackground(bg(favs.contains(chosen)?BLUE:Color.rgb(71,85,105),18));}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        box.addView(sp,new LinearLayout.LayoutParams(0,78,1));box.addView(star,new LinearLayout.LayoutParams(72,78));box.setTag(sp);return box;
    }
    LinearLayout optionList(ArrayList<String> values,String selected,HashSet<String> favs,int kind){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);for(String val:values){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);Button choose=action(val.equals(selected)?"✓  "+val:val,val.equals(selected)?BLUE:Color.rgb(71,85,105));choose.setTextSize(13);row.addView(choose,new LinearLayout.LayoutParams(0,50,1));Button star=action(favs.contains(val)?"★":"☆",favs.contains(val)?BLUE:Color.rgb(71,85,105));star.setTextSize(21);row.addView(star,new LinearLayout.LayoutParams(58,50));box.addView(row,lp(0,0,0,5));choose.setOnClickListener(v->{box.setTag(val);for(int i=0;i<box.getChildCount();i++){View q=box.getChildAt(i);if(q instanceof LinearLayout){}}for(int i=0;i<box.getChildCount();i++){LinearLayout rr=(LinearLayout)box.getChildAt(i);Button cb=(Button)rr.getChildAt(0);String txt=cb.getText().toString().replace("✓  ","");cb.setBackground(bg(txt.equals(val)?BLUE:Color.rgb(71,85,105),18));cb.setText(txt.equals(val)?"✓  "+txt:txt);}});star.setOnClickListener(v->{if(favs.contains(val))favs.remove(val);else favs.add(val);save();showForm();});}
        box.setTag(selected);return box;}
    LinearLayout choiceList(String[] values,String selected){
        ArrayList<String>a=new ArrayList<>(Arrays.asList(values));LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.HORIZONTAL);box.setGravity(Gravity.CENTER);box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(String val:a){Button b=action(val,val.equals(selected)?BLUE:Color.rgb(71,85,105));b.setTextSize(14);b.setMinHeight(82);box.addView(b,new LinearLayout.LayoutParams(0,82,1));
            if(!val.equals(a.get(a.size()-1)))box.addView(gap(7),new LinearLayout.LayoutParams(7,1));
            b.setOnClickListener(v->{box.setTag(val);for(int i=0;i<box.getChildCount();i++){View q=box.getChildAt(i);if(q instanceof Button){String txt=((Button)q).getText().toString().replace("✓  ","");((Button)q).setBackground(bg(txt.equals(val)?BLUE:Color.rgb(71,85,105),18));((Button)q).setText(txt.equals(val)?"✓  "+txt:txt);}}});
        }box.setTag(selected);return box;
    }

    LinearLayout fieldWrap(View v){LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(14,0,14,0);c.setBackground(bg(CARD,16));c.setMinimumHeight(62);c.addView(v,new LinearLayout.LayoutParams(-1,62));return c;}
    void addSymbolAndRefresh(){final EditText e=new EditText(this);e.setSingleLine();e.setInputType(InputType.TYPE_CLASS_TEXT);e.setHint("مثلاً USD/TRY");AlertDialog d=new AlertDialog.Builder(this).setTitle("افزودن نماد جدید").setView(e).setPositiveButton("افزودن",null).setNegativeButton("انصراف",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String s=cleanSymbol(e.getText().toString().trim().toUpperCase(Locale.US));if(s.isEmpty()){e.setError("نام نماد را وارد کنید");return;}if(!symbols.contains(s))symbols.add(s);save();d.dismiss();showForm();}));d.show();e.requestFocus();d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);}
    EditText numEdit(String hint,String value){EditText e=new EditText(this);e.setText(value);e.setHint(hint);e.setSingleLine(true);e.setTextSize(20);e.setTextColor(NAVY);e.setHintTextColor(MUTED);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(12,0,12,0);e.setSelectAllOnFocus(false);e.setBackgroundColor(Color.TRANSPARENT);e.setIncludeFontPadding(true);e.setMinHeight(62);return e;}

    String normalizeNumber(String s){if(s==null)return "";s=s.trim().replace(",",".").replace("٫",".").replace("٬","");StringBuilder b=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>='۰'&&c<='۹')b.append((char)('0'+(c-'۰')));else if(c>='٠'&&c<='٩')b.append((char)('0'+(c-'٠')));else b.append(c);}return b.toString();}
    Spinner spin(String[] a,String val){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));select(s,val);return s;}
    void select(Spinner s,String v){for(int i=0;i<s.getCount();i++)if(s.getItemAtPosition(i).toString().equals(v)){s.setSelection(i);return;}}

    void showReports(){
        LinearLayout r=new LinearLayout(this);page(r,"گزارش‌ها","گزارش روزانه، هفتگی، ماهانه و سالانه");
        LinearLayout calChoice=choiceList(new String[]{"شمسی","میلادی"},db.getString("reportCalendar","شمسی").equals("میلادی")?"میلادی":"شمسی");
        r.addView(text("نوع تقویم گزارش",14,MUTED));r.addView(calChoice,lp(0,0,0,12));
        Button refresh=action("✓  نمایش گزارش",BLUE);r.addView(refresh,lp(0,0,0,12));
        LinearLayout reportsBox=new LinearLayout(this);reportsBox.setOrientation(LinearLayout.VERTICAL);r.addView(reportsBox);
        Runnable rebuild=()->{
            reportsBox.removeAllViews();String mode=String.valueOf(calChoice.getTag());db.edit().putString("reportCalendar",mode).apply();
            ReportSets sets=buildReportSets(mode);
            reportsBox.addView(reportCard("امروز",summary(sets.day),BLUE),lp(0,0,0,10));
            reportsBox.addView(reportCard(mode.equals("شمسی")?"هفته جاری (شنبه تا جمعه)":"هفته جاری (دوشنبه تا یکشنبه)",summary(sets.week),GREEN),lp(0,0,0,10));
            reportsBox.addView(reportCard("ماه جاری",summary(sets.month),BLUE),lp(0,0,0,10));
            reportsBox.addView(reportCard("سال جاری",summary(sets.year),GREEN),lp(0,0,0,16));
            TextView h=text("تحلیل نمادها",19,NAVY);h.setTypeface(null,1);reportsBox.addView(h);
            HashMap<String,int[]> map=new HashMap<>();for(Trade t:trades){int[] a=map.computeIfAbsent(t.symbol,k->new int[2]);a[0]++;if(t.win)a[1]++;}
            ArrayList<String> keys=new ArrayList<>(map.keySet());Collections.sort(keys,(a,b)->{int c=Double.compare(rate(map.get(b)),rate(map.get(a)));return c!=0?(int)c:Integer.compare(map.get(b)[0],map.get(a)[0]);});
            if(keys.isEmpty())reportsBox.addView(empty("هنوز داده‌ای برای تحلیل وجود ندارد."));for(String ss:keys){int[] a=map.get(ss);reportsBox.addView(symbolRow(ss,a[0],rate(a)),lp(0,0,0,8));}
        };
        calChoice.setTag(db.getString("reportCalendar","شمسی").equals("میلادی")?"میلادی":"شمسی");
        // choiceList changes its tag on button taps; press نمایش گزارش to rebuild using the selected calendar.
        refresh.setOnClickListener(v->rebuild.run());
        rebuild.run();
        nav(r,3);setPage(r);
    }
    LinearLayout reportCard(String title,String value,int color){LinearLayout c=card();c.setPadding(18,22,18,22);TextView t=text(title,16,MUTED);TextView v=text(value,17,color);v.setTypeface(null,1);c.addView(t);c.addView(v);c.setMinimumHeight(450);return c;}

    void showSettings(){LinearLayout r=new LinearLayout(this);page(r,"تنظیمات","مدیریت برنامه و ظاهر");Button favb=action("★  مدیریت نمادهای محبوب",BLUE);favb.setOnClickListener(v->manageSymbols());r.addView(favb,lp(0,0,0,10));Button add=action("＋  افزودن نماد جدید",Color.rgb(71,85,105));add.setOnClickListener(v->addSymbolDialog());r.addView(add,lp(0,0,0,10));Button theme=action(darkMode?"☀  حالت Day Mode":"☾  حالت Night Mode",Color.rgb(71,85,105));theme.setOnClickListener(v->{darkMode=!darkMode;db.edit().putBoolean("dark",darkMode).apply();applyTheme();showSettings();});r.addView(theme,lp(0,0,0,10));Button backup=action("↗  اشتراک‌گذاری پشتیبان JSON",Color.rgb(71,85,105));backup.setOnClickListener(v->shareBackup());r.addView(backup,lp(0,0,0,10));TextView info=text("تعداد معاملات: "+trades.size()+"\nتعداد نمادها: "+symbols.size()+"\n\nDesign by Ali Bazargani",13,MUTED);info.setPadding(8,24,8,8);r.addView(info);nav(r,4);setPage(r);}

    void addSymbolDialog(){final EditText e=new EditText(this);e.setSingleLine();e.setHint("مثلاً USD/TRY");new AlertDialog.Builder(this).setTitle("افزودن نماد").setView(e).setPositiveButton("افزودن",(d,w)->{String s=e.getText().toString().trim().toUpperCase(Locale.US);if(!s.isEmpty()&&!symbols.contains(s)){symbols.add(s);save();Toast.makeText(this,"نماد اضافه شد",Toast.LENGTH_SHORT).show();}}).setNegativeButton("انصراف",null).show();}
    void manageSymbols(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(18,18,18,12);r.setBackgroundColor(BG);r.addView(text("نمادها و محبوب‌ها",25,NAVY));r.addView(text("ستاره را لمس کنید تا نماد بالای لیست قرار بگیرد.",13,MUTED));ScrollView sv=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);for(String s:new ArrayList<>(symbols)){LinearLayout row=card();row.setOrientation(LinearLayout.HORIZONTAL);TextView star=text(fav.contains(s)?"★":"☆",28,fav.contains(s)?BLUE:MUTED);star.setGravity(Gravity.CENTER);row.addView(star,new LinearLayout.LayoutParams(58,60));TextView name=text(cleanSymbol(s),16,NAVY);row.addView(name,new LinearLayout.LayoutParams(0,60,1));star.setOnClickListener(v->{if(fav.contains(s))fav.remove(s);else fav.add(s);save();manageSymbols();});Button del=action("حذف",RED);del.setTextSize(12);row.addView(del,new LinearLayout.LayoutParams(70,50));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف نماد؟").setMessage("معاملات قبلی باقی می‌مانند.").setPositiveButton("حذف",(d,w)->{symbols.remove(s);fav.remove(s);save();manageSymbols();}).setNegativeButton("انصراف",null).show());list.addView(row,lp(0,0,0,8));}sv.addView(list);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));Button back=action("بازگشت",Color.rgb(71,85,105));back.setOnClickListener(v->showSettings());r.addView(back);setPage(r);}
    void shareBackup(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/json");i.putExtra(Intent.EXTRA_TEXT,backupJson().toString());startActivity(Intent.createChooser(i,"ارسال پشتیبان"));}catch(Exception e){Toast.makeText(this,"امکان اشتراک‌گذاری وجود ندارد",Toast.LENGTH_SHORT).show();}}
    JSONObject backupJson()throws Exception{JSONObject root=new JSONObject();root.put("version",1);root.put("createdAt",System.currentTimeMillis());JSONArray a=new JSONArray();for(Trade t:trades){JSONObject o=new JSONObject();o.put("id",t.id);o.put("symbol",cleanSymbol(t.symbol));o.put("dir",t.dir);o.put("tf",t.tf);o.put("expiry",t.expiry);o.put("amount",t.amount);o.put("payout",t.payout);o.put("win",t.win);o.put("time",t.time);o.put("miladiDate",t.miladiDate);o.put("shamsiDate",t.shamsiDate);if(t.image!=null)o.put("image",t.image);a.put(o);}root.put("trades",a);root.put("symbols",new JSONArray(symbols));root.put("favorites",new JSONArray(fav));root.put("favoriteTimeframes",new JSONArray(favTf));root.put("favoriteExpiries",new JSONArray(favExp));return root;}

    String cleanSymbol(String s){if(s==null)return "";return s.trim().replaceFirst("^[★☆\\s]+","");}
ArrayList<String> orderedSymbolList(){ArrayList<String>x=new ArrayList<>();for(String s:symbols){String cs=cleanSymbol(s);if(!cs.isEmpty()&&!x.contains(cs))x.add(cs);}Collections.sort(x,(a,b)->{boolean af=fav.contains(a),bf=fav.contains(b);if(af!=bf)return af?-1:1;return a.compareToIgnoreCase(b);});return x;}
    ArrayList<String> orderedSymbols(HashMap<String,int[]>m){ArrayList<String>x=new ArrayList<>(m.keySet());Collections.sort(x,(a,b)->{int c=Double.compare(rate(m.get(b)),rate(m.get(a)));return c!=0?c:Integer.compare(m.get(b)[0],m.get(a)[0]);});return x;}
    double rate(int[]a){return a[0]==0?0:100.0*a[1]/a[0];}double pnl(Trade t){return t.win?t.amount*t.payout/100.0:-t.amount;}
    String summary(ArrayList<Trade>a){int w=0;double p=0;for(Trade t:a){if(t.win)w++;p+=pnl(t);}return a.size()+" معامله • "+w+" برد • "+(a.size()-w)+" باخت • Win Rate "+(a.isEmpty()?"0":String.format(Locale.US,"%.1f",100.0*w/a.size()))+"٪ • P/L "+String.format(Locale.US,"%.2f",p);}
    boolean sameDay(long x){Calendar a=Calendar.getInstance(),b=Calendar.getInstance();a.setTimeInMillis(x);return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
    static class JalaliDate{int y,m,d;JalaliDate(int yy,int mm,int dd){y=yy;m=mm;d=dd;}}
    JalaliDate gregorianToJalali(int gy,int gm,int gd){
        int[] gdm={0,31,28,31,30,31,30,31,31,30,31,30,31};int[] jdm={0,31,31,31,31,31,31,30,30,30,30,30,29};
        int gy2=gy-1600,gm2=gm-1,gd2=gd-1;int gdn=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;
        for(int i=0;i<gm2;i++)gdn+=gdm[i+1];if(gm2>1&&((gy%4==0&&gy%100!=0)||(gy%400==0)))gdn++;
        gdn+=gd2;int jdn=gdn-79;int jnp=jdn/12053;jdn%=12053;int jy=979+33*jnp+4*(jdn/1461);jdn%=1461;if(jdn>=366){jy+=(jdn-1)/365;jdn=(jdn-1)%365;}
        int jm=0;for(int i=1;i<=12;i++){int md=jdm[i];if(i==12&&((jy%33==1)||(jy%33==5)||(jy%33==9)||(jy%33==13)||(jy%33==17)||(jy%33==22)||(jy%33==26)||(jy%33==30)))md=30;if(jdn<md){jm=i;break;}jdn-=md;}return new JalaliDate(jy,jm,jdn+1);
    }
    JalaliDate jalaliNow(long time){Calendar c=Calendar.getInstance();c.setTimeInMillis(time);return gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
    String fmtGregorianDateTime(long t){return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss",Locale.US).format(new Date(t));}
    String fmtJalaliDateTime(long t){Calendar c=Calendar.getInstance();c.setTimeInMillis(t);JalaliDate j=gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));return String.format(Locale.US,"%04d/%02d/%02d %02d:%02d:%02d",j.y,j.m,j.d,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),c.get(Calendar.SECOND));}
    boolean sameGregorianDay(long a,long b){Calendar x=Calendar.getInstance(),y=Calendar.getInstance();x.setTimeInMillis(a);y.setTimeInMillis(b);return x.get(Calendar.YEAR)==y.get(Calendar.YEAR)&&x.get(Calendar.DAY_OF_YEAR)==y.get(Calendar.DAY_OF_YEAR);}
    int jalaliMonthDays(int y,int m){if(m<=6)return 31;if(m<=11)return 30;int r=y%33;return (r==1||r==5||r==9||r==13||r==17||r==22||r==26||r==30)?30:29;}
    boolean sameJalaliDate(long t,JalaliDate now){JalaliDate j=jalaliNow(t);return j.y==now.y&&j.m==now.m&&j.d==now.d;}
    boolean sameJalaliMonth(long t,JalaliDate now){JalaliDate j=jalaliNow(t);return j.y==now.y&&j.m==now.m;}
    boolean sameJalaliYear(long t,JalaliDate now){return jalaliNow(t).y==now.y;}
    boolean inGregorianWeek(long t,long now){Calendar start=Calendar.getInstance();start.setTimeInMillis(now);zero(start);int dow=start.get(Calendar.DAY_OF_WEEK);int back=(dow+5)%7;start.add(Calendar.DAY_OF_MONTH,-back);Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_MONTH,7);return t>=start.getTimeInMillis()&&t<end.getTimeInMillis();}
    boolean inJalaliWeek(long t,long now){Calendar start=Calendar.getInstance();start.setTimeInMillis(now);zero(start);int dow=start.get(Calendar.DAY_OF_WEEK);int back=dow%7;start.add(Calendar.DAY_OF_MONTH,-back);Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_MONTH,7);return t>=start.getTimeInMillis()&&t<end.getTimeInMillis();}
    static class ReportSets{ArrayList<Trade>day=new ArrayList<>(),week=new ArrayList<>(),month=new ArrayList<>(),year=new ArrayList<>();}
    ReportSets buildReportSets(String mode){ReportSets r=new ReportSets();long now=System.currentTimeMillis();JalaliDate jnow=jalaliNow(now);for(Trade t:trades){if("شمسی".equals(mode)){if(sameJalaliDate(t.time,jnow))r.day.add(t);if(inJalaliWeek(t.time,now))r.week.add(t);if(sameJalaliMonth(t.time,jnow))r.month.add(t);if(sameJalaliYear(t.time,jnow))r.year.add(t);}else{if(sameGregorianDay(t.time,now))r.day.add(t);if(inGregorianWeek(t.time,now))r.week.add(t);Calendar c=Calendar.getInstance();c.setTimeInMillis(now);Calendar tc=Calendar.getInstance();tc.setTimeInMillis(t.time);if(c.get(Calendar.YEAR)==tc.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==tc.get(Calendar.MONTH))r.month.add(t);if(c.get(Calendar.YEAR)==tc.get(Calendar.YEAR))r.year.add(t);}}return r;}
    void zero(Calendar c){c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);}
    String fmt(double d){return String.format(Locale.US,"%.2f",d).replaceAll("\\.00$","");}String fmtTime(long t){return new SimpleDateFormat("HH:mm",Locale.US).format(new Date(t));}String fmtDate(long t){return new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.US).format(new Date(t));}
    LinearLayout.LayoutParams lp(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(l,t,r,b);return p;}

    static class Trade{
        String id=UUID.randomUUID().toString(),symbol="",dir="CALL",tf="15 ثانیه",expiry="30 ثانیه",image=null,shamsiDate="",miladiDate="";
        double amount=0,payout=0;boolean win=true;long time=System.currentTimeMillis();
    }
    void load(){
        try{
            JSONArray a=new JSONArray(db.getString("trades","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);Trade t=new Trade();t.id=o.optString("id",UUID.randomUUID().toString());t.symbol=cleanSymbol(o.optString("symbol"));t.dir=o.optString("dir","CALL");t.tf=o.optString("tf","15 ثانیه");t.expiry=o.optString("expiry","30 ثانیه");t.amount=o.optDouble("amount",0);t.payout=o.optDouble("payout",0);t.win=o.optBoolean("win",true);t.time=o.optLong("time",System.currentTimeMillis());t.image=o.optString("image",null);
                t.miladiDate=o.optString("miladiDate","");t.shamsiDate=o.optString("shamsiDate","");if(t.miladiDate.isEmpty())t.miladiDate=fmtGregorianDateTime(t.time);if(t.shamsiDate.isEmpty())t.shamsiDate=fmtJalaliDateTime(t.time);trades.add(t);
            }
            String sy=db.getString("symbols","");if(sy.isEmpty())symbols.addAll(Arrays.asList(defaults));else for(String ss:sy.split("\\|",-1)){ss=cleanSymbol(ss);if(!ss.isEmpty()&&!symbols.contains(ss))symbols.add(ss);}
            String f=db.getString("fav","");if(!f.isEmpty())for(String ss:f.split("\\|",-1)){ss=cleanSymbol(ss);if(!ss.isEmpty())fav.add(ss);}String ft=db.getString("favTf","");if(!ft.isEmpty())favTf.addAll(Arrays.asList(ft.split("\\|",-1)));String fe=db.getString("favExp","");if(!fe.isEmpty())favExp.addAll(Arrays.asList(fe.split("\\|",-1)));
            save();
        }catch(Exception e){if(symbols.isEmpty())symbols.addAll(Arrays.asList(defaults));}
    }
    void save(){
        try{
            for(int i=0;i<symbols.size();i++)symbols.set(i,cleanSymbol(symbols.get(i)));for(Trade tt:trades){tt.symbol=cleanSymbol(tt.symbol);if(tt.miladiDate==null||tt.miladiDate.isEmpty())tt.miladiDate=fmtGregorianDateTime(tt.time);if(tt.shamsiDate==null||tt.shamsiDate.isEmpty())tt.shamsiDate=fmtJalaliDateTime(tt.time);}
            fav.removeIf(x->x==null||cleanSymbol(x).isEmpty());JSONArray a=new JSONArray();for(Trade t:trades){JSONObject o=new JSONObject();o.put("id",t.id);o.put("symbol",cleanSymbol(t.symbol));o.put("dir",t.dir);o.put("tf",t.tf);o.put("expiry",t.expiry);o.put("amount",t.amount);o.put("payout",t.payout);o.put("win",t.win);o.put("time",t.time);o.put("miladiDate",t.miladiDate);o.put("shamsiDate",t.shamsiDate);if(t.image!=null)o.put("image",t.image);a.put(o);}
            db.edit().putString("trades",a.toString()).putString("symbols",String.join("|",symbols)).putString("fav",String.join("|",fav)).putString("favTf",String.join("|",favTf)).putString("favExp",String.join("|",favExp)).apply();
        }catch(Exception ignored){}
    }
    @Override protected void onActivityResult(int rq,int rc,Intent data){super.onActivityResult(rq,rc,data);if(rq==55&&rc==RESULT_OK&&data!=null&&data.getData()!=null){pendingImage=data.getData();try{getContentResolver().takePersistableUriPermission(pendingImage,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}Toast.makeText(this,"Screenshot انتخاب شد",Toast.LENGTH_SHORT).show();}}
}
